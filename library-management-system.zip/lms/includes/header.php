<?php
/**
 * header.php
 * ---------------------------------------------------------------------
 * Included at the top of every authenticated page. Expects the
 * including page to have already required config.php and to set:
 *   $page_title  - string shown in <title> and the topbar
 *   $active_nav  - string key matching a nav item (for the "active" state)
 * ---------------------------------------------------------------------
 */
$page_title = $page_title ?? 'Library Management System';
$active_nav = $active_nav ?? '';
$role = $_SESSION['role'] ?? 'student';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= h($page_title) ?> · Athenaeum LMS</title>
<link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><rect width=%22100%22 height=%22100%22 rx=%2220%22 fill=%22%231B2A4A%22/><text x=%2250%22 y=%2266%22 font-size=%2255%22 fill=%22%23B8862E%22 text-anchor=%22middle%22 font-family=%22Georgia,serif%22>A</text></svg>">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="app-shell">

    <div class="sidebar-backdrop"></div>
    <aside class="sidebar">
        <div class="brand">
            <div class="glyph">A</div>
            <span>Athenaeum</span>
        </div>

        <?php if ($role === 'admin'): ?>
            <div class="nav-section-label">Overview</div>
            <a href="<?= BASE_URL ?>/admin/dashboard.php" class="nav-link <?= $active_nav === 'dashboard' ? 'active' : '' ?>"><i class="fa-solid fa-chart-simple"></i> Dashboard</a>

            <div class="nav-section-label">Catalog</div>
            <a href="<?= BASE_URL ?>/admin/books.php" class="nav-link <?= $active_nav === 'books' ? 'active' : '' ?>"><i class="fa-solid fa-book"></i> Books</a>
            <a href="<?= BASE_URL ?>/admin/categories.php" class="nav-link <?= $active_nav === 'categories' ? 'active' : '' ?>"><i class="fa-solid fa-tags"></i> Categories</a>
            <a href="<?= BASE_URL ?>/admin/authors.php" class="nav-link <?= $active_nav === 'authors' ? 'active' : '' ?>"><i class="fa-solid fa-feather"></i> Authors</a>
            <a href="<?= BASE_URL ?>/admin/publishers.php" class="nav-link <?= $active_nav === 'publishers' ? 'active' : '' ?>"><i class="fa-solid fa-building"></i> Publishers</a>

            <div class="nav-section-label">Circulation</div>
            <a href="<?= BASE_URL ?>/admin/issue_book.php" class="nav-link <?= $active_nav === 'issue' ? 'active' : '' ?>"><i class="fa-solid fa-right-left"></i> Issue Book</a>
            <a href="<?= BASE_URL ?>/admin/returns.php" class="nav-link <?= $active_nav === 'returns' ? 'active' : '' ?>"><i class="fa-solid fa-rotate-left"></i> Returns &amp; Renewals</a>
            <a href="<?= BASE_URL ?>/admin/fines.php" class="nav-link <?= $active_nav === 'fines' ? 'active' : '' ?>"><i class="fa-solid fa-coins"></i> Fines</a>

            <div class="nav-section-label">People &amp; Reports</div>
            <a href="<?= BASE_URL ?>/admin/students.php" class="nav-link <?= $active_nav === 'students' ? 'active' : '' ?>"><i class="fa-solid fa-user-graduate"></i> Students</a>
            <a href="<?= BASE_URL ?>/admin/reports.php" class="nav-link <?= $active_nav === 'reports' ? 'active' : '' ?>"><i class="fa-solid fa-file-lines"></i> Reports</a>
        <?php else: ?>
            <div class="nav-section-label">My Library</div>
            <a href="<?= BASE_URL ?>/student/dashboard.php" class="nav-link <?= $active_nav === 'dashboard' ? 'active' : '' ?>"><i class="fa-solid fa-chart-simple"></i> Dashboard</a>
            <a href="<?= BASE_URL ?>/student/browse_books.php" class="nav-link <?= $active_nav === 'browse' ? 'active' : '' ?>"><i class="fa-solid fa-magnifying-glass"></i> Browse Books</a>
            <a href="<?= BASE_URL ?>/student/my_books.php" class="nav-link <?= $active_nav === 'my_books' ? 'active' : '' ?>"><i class="fa-solid fa-book-bookmark"></i> My Books</a>
            <a href="<?= BASE_URL ?>/student/fines.php" class="nav-link <?= $active_nav === 'fines' ? 'active' : '' ?>"><i class="fa-solid fa-coins"></i> My Fines</a>
        <?php endif; ?>

        <div class="sidebar-footer">
            <div class="who"><?= h($_SESSION['full_name'] ?? '') ?></div>
            <div class="role-tag"><?= $role === 'admin' ? 'Administrator' : 'Student' ?></div>
            <a href="<?= BASE_URL ?>/auth/logout.php" class="d-inline-block mt-2 text-decoration-none" style="color:#B8862E; font-size:13px;">
                <i class="fa-solid fa-arrow-right-from-bracket"></i> Sign out
            </a>
        </div>
    </aside>

    <div class="main-col">
        <header class="topbar">
            <div class="d-flex align-items-center gap-3">
                <button class="mobile-toggle"><i class="fa-solid fa-bars"></i></button>
                <h1><?= h($page_title) ?></h1>
            </div>
            <div class="topbar-actions">
                <span class="text-muted-ink d-none d-sm-inline" style="font-size:13px;">
                    <i class="fa-regular fa-calendar"></i> <?= date('l, d M Y') ?>
                </span>
            </div>
        </header>

        <div class="content">
            <?php render_flash(); ?>
