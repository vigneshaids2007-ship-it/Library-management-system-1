<?php
/**
 * functions.php
 * ---------------------------------------------------------------------
 * Shared helper functions used across the whole application:
 *  - authentication / authorization guards
 *  - flash messaging (success / error banners)
 *  - fine + due-date calculations
 *  - small formatting / sanitisation helpers
 * ---------------------------------------------------------------------
 */

/** Redirect to login page if the user is not signed in. */
function require_login()
{
    if (empty($_SESSION['user_id'])) {
        header('Location: ' . BASE_URL . '/auth/login.php');
        exit;
    }
}

/** Redirect away unless the signed-in user has the given role. */
function require_role($role)
{
    require_login();
    if ($_SESSION['role'] !== $role) {
        header('Location: ' . BASE_URL . '/index.php');
        exit;
    }
}

/** True if the current visitor is logged in. */
function is_logged_in()
{
    return !empty($_SESSION['user_id']);
}

/** True if the current visitor is an admin. */
function is_admin()
{
    return is_logged_in() && $_SESSION['role'] === 'admin';
}

/** Store a one-time flash message to show on the next page load. */
function set_flash($type, $message)
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

/** Pull (and clear) the current flash message, if any. */
function get_flash()
{
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/** Render the flash message banner (call this right under the navbar). */
function render_flash()
{
    $flash = get_flash();
    if (!$flash) return;
    $type = $flash['type'] === 'error' ? 'danger' : $flash['type'];
    echo '<div class="alert alert-' . htmlspecialchars($type) . ' alert-dismissible fade show app-alert" role="alert">'
        . htmlspecialchars($flash['message'])
        . '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>'
        . '</div>';
}

/** Shorthand sanitiser for echoing user data into HTML. */
function h($value)
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Calculate the fine (in currency units) for an issue that is/was overdue.
 * $due_date / $return_date are 'Y-m-d' strings. If $return_date is null,
 * "today" is used (i.e. the fine as it stands right now for a still-issued book).
 */
function calculate_fine($due_date, $return_date = null)
{
    $due = new DateTime($due_date);
    $end = $return_date ? new DateTime($return_date) : new DateTime('today');
    if ($end <= $due) {
        return 0.00;
    }
    $days_late = $due->diff($end)->days;
    return round($days_late * FINE_PER_DAY, 2);
}

/** Number of days between today and the due date (negative = overdue). */
function days_until_due($due_date)
{
    $due = new DateTime($due_date);
    $today = new DateTime('today');
    $diff = $today->diff($due);
    return $today > $due ? -$diff->days : $diff->days;
}

/** Small helper to output a colored status pill for a due date. */
function due_status_badge($due_date, $status)
{
    if ($status === 'returned') {
        return '<span class="badge badge-soft badge-returned">Returned</span>';
    }
    $days = days_until_due($due_date);
    if ($days < 0) {
        return '<span class="badge badge-soft badge-overdue">Overdue ' . abs($days) . 'd</span>';
    } elseif ($days <= 3) {
        return '<span class="badge badge-soft badge-duesoon">Due in ' . $days . 'd</span>';
    }
    return '<span class="badge badge-soft badge-ok">Due in ' . $days . 'd</span>';
}

/** Format a number as currency for display. */
function money($amount)
{
    return '$' . number_format((float)$amount, 2);
}

/**
 * Sync a book's outstanding fine rows so that `fines` always reflects
 * reality for any book still on loan. Call this before rendering
 * fines/overdue reports so numbers are always fresh.
 */
function sync_overdue_fines(PDO $pdo)
{
    $stmt = $pdo->query("SELECT issue_id, user_id, due_date FROM book_issues
                          WHERE status = 'issued' AND due_date < CURDATE()");
    $overdue = $stmt->fetchAll();

    foreach ($overdue as $row) {
        $amount = calculate_fine($row['due_date']);
        if ($amount <= 0) continue;

        $check = $pdo->prepare("SELECT fine_id FROM fines WHERE issue_id = ? AND status = 'unpaid'");
        $check->execute([$row['issue_id']]);
        $existing = $check->fetch();

        if ($existing) {
            $upd = $pdo->prepare("UPDATE fines SET amount = ? WHERE fine_id = ?");
            $upd->execute([$amount, $existing['fine_id']]);
        } else {
            $ins = $pdo->prepare("INSERT INTO fines (issue_id, user_id, amount, reason, status) VALUES (?, ?, ?, 'Late return', 'unpaid')");
            $ins->execute([$row['issue_id'], $row['user_id'], $amount]);
        }
    }
}

/** Generate a CSRF token and stash it in the session. */
function csrf_token()
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/** Verify a submitted CSRF token matches the session's token. */
function csrf_verify($token)
{
    return !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], (string)$token);
}
