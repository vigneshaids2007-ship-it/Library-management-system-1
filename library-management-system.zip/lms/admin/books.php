<?php
/**
 * admin/books.php
 * ---------------------------------------------------------------------
 * Lists all books with search (title / author / ISBN / category) and
 * links out to the add/edit form. Deletion is handled inline via POST.
 * ---------------------------------------------------------------------
 */
require_once __DIR__ . '/../config/config.php';
require_role('admin');

$page_title = 'Books';
$active_nav = 'books';

/* ---------------- Handle delete ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_book_id'])) {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        set_flash('error', 'Invalid request token.');
    } else {
        $bookId = (int)$_POST['delete_book_id'];
        $inUse = $pdo->prepare("SELECT COUNT(*) FROM book_issues WHERE book_id = ? AND status = 'issued'");
        $inUse->execute([$bookId]);
        if ($inUse->fetchColumn() > 0) {
            set_flash('error', 'Cannot delete: this book has copies currently issued.');
        } else {
            $del = $pdo->prepare("DELETE FROM books WHERE book_id = ?");
            $del->execute([$bookId]);
            set_flash('success', 'Book deleted successfully.');
        }
    }
    header('Location: ' . BASE_URL . '/admin/books.php');
    exit;
}

/* ---------------- Search / filter ---------------- */
$q = trim($_GET['q'] ?? '');
$category_filter = $_GET['category'] ?? '';

$sql = "SELECT b.*, c.category_name, a.author_name, p.publisher_name
        FROM books b
        LEFT JOIN categories c ON c.category_id = b.category_id
        LEFT JOIN authors a ON a.author_id = b.author_id
        LEFT JOIN publishers p ON p.publisher_id = b.publisher_id
        WHERE 1=1";
$params = [];

if ($q !== '') {
    $sql .= " AND (b.title LIKE ? OR a.author_name LIKE ? OR b.isbn LIKE ? OR c.category_name LIKE ?)";
    $like = "%$q%";
    array_push($params, $like, $like, $like, $like);
}
if ($category_filter !== '') {
    $sql .= " AND b.category_id = ?";
    $params[] = $category_filter;
}
$sql .= " ORDER BY b.added_on DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$books = $stmt->fetchAll();

$categories = $pdo->query("SELECT * FROM categories ORDER BY category_name")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="panel">
    <div class="panel-title">
        <span>Book catalog <span class="text-muted-ink" style="font-size:13px; font-weight:400;">(<?= count($books) ?> results)</span></span>
        <a href="<?= BASE_URL ?>/admin/book_form.php" class="btn btn-brass btn-sm"><i class="fa-solid fa-plus"></i> Add Book</a>
    </div>

    <form method="GET" class="row g-2 mb-3">
        <div class="col-md-7">
            <input type="text" name="q" class="form-control" placeholder="Search by title, author, ISBN, or category…" value="<?= h($q) ?>">
        </div>
        <div class="col-md-3">
            <select name="category" class="form-select">
                <option value="">All categories</option>
                <?php foreach ($categories as $c): ?>
                    <option value="<?= $c['category_id'] ?>" <?= $category_filter == $c['category_id'] ? 'selected' : '' ?>><?= h($c['category_name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-2 d-grid">
            <button class="btn btn-ink"><i class="fa-solid fa-magnifying-glass"></i> Search</button>
        </div>
    </form>

    <?php if (!$books): ?>
        <div class="empty-state"><i class="fa-solid fa-book-open"></i>No books match your search.</div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Title</th><th>Author</th><th>Category</th><th>ISBN</th>
                    <th>Publisher</th><th>Copies</th><th>Status</th><th></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($books as $b): ?>
                <tr>
                    <td>
                        <div style="display:flex; align-items:center; gap:10px;">
                            <span style="width:6px;height:28px;border-radius:3px;background:<?= h($b['cover_color']) ?>;display:inline-block;"></span>
                            <span style="font-weight:600;"><?= h($b['title']) ?></span>
                        </div>
                    </td>
                    <td><?= h($b['author_name'] ?? '—') ?></td>
                    <td><?= h($b['category_name'] ?? '—') ?></td>
                    <td class="isbn"><?= h($b['isbn']) ?></td>
                    <td><?= h($b['publisher_name'] ?? '—') ?></td>
                    <td><?= (int)$b['available_copies'] ?> / <?= (int)$b['total_copies'] ?></td>
                    <td>
                        <?php if ($b['available_copies'] > 0): ?>
                            <span class="badge-soft badge-available">Available</span>
                        <?php else: ?>
                            <span class="badge-soft badge-outstock">Out of stock</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-end" style="white-space:nowrap;">
                        <a href="<?= BASE_URL ?>/admin/book_form.php?id=<?= $b['book_id'] ?>" class="btn btn-sm btn-outline-ink"><i class="fa-solid fa-pen"></i></a>
                        <form method="POST" class="d-inline" data-confirm="Delete '<?= h($b['title']) ?>'? This cannot be undone.">
                            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                            <input type="hidden" name="delete_book_id" value="<?= $b['book_id'] ?>">
                            <button type="submit" class="btn btn-sm btn-outline-ink text-danger"><i class="fa-solid fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
