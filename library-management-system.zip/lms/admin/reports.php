<?php
/**
 * admin/reports.php
 * ---------------------------------------------------------------------
 * Tabbed reporting view covering the four report types requested:
 * Issued, Returned, Available, and Overdue books. Each tab is a plain
 * table pulled straight from the relevant query - easy to print or
 * extend with CSV export later.
 * ---------------------------------------------------------------------
 */
require_once __DIR__ . '/../config/config.php';
require_role('admin');
sync_overdue_fines($pdo);

$page_title = 'Reports';
$active_nav = 'reports';
$type = $_GET['type'] ?? 'issued';
if (!in_array($type, ['issued', 'returned', 'available', 'overdue'], true)) $type = 'issued';

$rows = [];
if ($type === 'issued') {
    $rows = $pdo->query("
        SELECT bi.issue_date, bi.due_date, bi.status, b.title, b.isbn, u.full_name, u.email
        FROM book_issues bi JOIN books b ON b.book_id=bi.book_id JOIN users u ON u.user_id=bi.user_id
        WHERE bi.status = 'issued' ORDER BY bi.issue_date DESC
    ")->fetchAll();
} elseif ($type === 'returned') {
    $rows = $pdo->query("
        SELECT r.return_date, bi.issue_date, bi.due_date, b.title, b.isbn, u.full_name, u.email
        FROM returns r
        JOIN book_issues bi ON bi.issue_id = r.issue_id
        JOIN books b ON b.book_id = bi.book_id
        JOIN users u ON u.user_id = bi.user_id
        ORDER BY r.return_date DESC
    ")->fetchAll();
} elseif ($type === 'available') {
    $rows = $pdo->query("
        SELECT b.title, b.isbn, c.category_name, a.author_name, b.available_copies, b.total_copies
        FROM books b
        LEFT JOIN categories c ON c.category_id=b.category_id
        LEFT JOIN authors a ON a.author_id=b.author_id
        WHERE b.available_copies > 0 ORDER BY b.title
    ")->fetchAll();
} elseif ($type === 'overdue') {
    $rows = $pdo->query("
        SELECT bi.issue_date, bi.due_date, b.title, b.isbn, u.full_name, u.email,
               DATEDIFF(CURDATE(), bi.due_date) AS days_overdue
        FROM book_issues bi JOIN books b ON b.book_id=bi.book_id JOIN users u ON u.user_id=bi.user_id
        WHERE bi.status='issued' AND bi.due_date < CURDATE()
        ORDER BY days_overdue DESC
    ")->fetchAll();
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="panel">
    <div class="panel-title">
        <span>Reports</span>
        <button onclick="window.print()" class="btn btn-outline-ink btn-sm"><i class="fa-solid fa-print"></i> Print</button>
    </div>

    <ul class="nav nav-pills mb-3" style="gap:8px;">
        <?php foreach (['issued'=>'Issued','returned'=>'Returned','available'=>'Available','overdue'=>'Overdue'] as $key => $label): ?>
            <li class="nav-item">
                <a class="btn btn-sm <?= $type===$key ? 'btn-ink' : 'btn-outline-ink' ?>" href="?type=<?= $key ?>"><?= $label ?></a>
            </li>
        <?php endforeach; ?>
    </ul>

    <?php if (!$rows): ?>
        <div class="empty-state"><i class="fa-solid fa-file-lines"></i>No records for this report.</div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table table-hover">
        <?php if ($type === 'issued'): ?>
            <thead><tr><th>Book</th><th>ISBN</th><th>Student</th><th>Issued</th><th>Due</th><th>Status</th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td><?= h($r['title']) ?></td>
                    <td class="isbn"><?= h($r['isbn']) ?></td>
                    <td><?= h($r['full_name']) ?> <span class="text-muted-ink">(<?= h($r['email']) ?>)</span></td>
                    <td class="due-date"><?= h($r['issue_date']) ?></td>
                    <td class="due-date"><?= h($r['due_date']) ?></td>
                    <td><?= due_status_badge($r['due_date'], $r['status']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>

        <?php elseif ($type === 'returned'): ?>
            <thead><tr><th>Book</th><th>ISBN</th><th>Student</th><th>Issued</th><th>Due</th><th>Returned</th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td><?= h($r['title']) ?></td>
                    <td class="isbn"><?= h($r['isbn']) ?></td>
                    <td><?= h($r['full_name']) ?> <span class="text-muted-ink">(<?= h($r['email']) ?>)</span></td>
                    <td class="due-date"><?= h($r['issue_date']) ?></td>
                    <td class="due-date"><?= h($r['due_date']) ?></td>
                    <td class="due-date"><?= h($r['return_date']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>

        <?php elseif ($type === 'available'): ?>
            <thead><tr><th>Book</th><th>ISBN</th><th>Category</th><th>Author</th><th>Available</th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td><?= h($r['title']) ?></td>
                    <td class="isbn"><?= h($r['isbn']) ?></td>
                    <td><?= h($r['category_name'] ?? '—') ?></td>
                    <td><?= h($r['author_name'] ?? '—') ?></td>
                    <td><span class="badge-soft badge-available"><?= $r['available_copies'] ?> / <?= $r['total_copies'] ?></span></td>
                </tr>
            <?php endforeach; ?>
            </tbody>

        <?php elseif ($type === 'overdue'): ?>
            <thead><tr><th>Book</th><th>ISBN</th><th>Student</th><th>Due date</th><th>Days overdue</th><th>Est. fine</th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td><?= h($r['title']) ?></td>
                    <td class="isbn"><?= h($r['isbn']) ?></td>
                    <td><?= h($r['full_name']) ?> <span class="text-muted-ink">(<?= h($r['email']) ?>)</span></td>
                    <td class="due-date"><?= h($r['due_date']) ?></td>
                    <td><span class="badge-soft badge-overdue"><?= (int)$r['days_overdue'] ?> days</span></td>
                    <td style="font-weight:600;"><?= money($r['days_overdue'] * FINE_PER_DAY) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        <?php endif; ?>
        </table>
    </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
