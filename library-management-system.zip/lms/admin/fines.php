<?php
/**
 * admin/fines.php
 * ---------------------------------------------------------------------
 * Shows all fines and lets the admin mark them paid or waived.
 * Calls sync_overdue_fines() first so amounts for books still on loan
 * are always up to date with today's date.
 * ---------------------------------------------------------------------
 */
require_once __DIR__ . '/../config/config.php';
require_role('admin');
sync_overdue_fines($pdo);

$page_title = 'Fines';
$active_nav = 'fines';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        set_flash('error', 'Invalid request token.');
    } else {
        $fine_id = (int)($_POST['fine_id'] ?? 0);
        $action = $_POST['action'] ?? '';
        if ($action === 'paid') {
            $pdo->prepare("UPDATE fines SET status='paid', paid_at=NOW() WHERE fine_id=?")->execute([$fine_id]);
            set_flash('success', 'Fine marked as paid.');
        } elseif ($action === 'waive') {
            $pdo->prepare("UPDATE fines SET status='waived', paid_at=NOW() WHERE fine_id=?")->execute([$fine_id]);
            set_flash('success', 'Fine waived.');
        }
    }
    header('Location: ' . BASE_URL . '/admin/fines.php');
    exit;
}

$status_filter = $_GET['status'] ?? 'unpaid';
$sql = "SELECT f.*, u.full_name, u.email, b.title
        FROM fines f
        JOIN users u ON u.user_id = f.user_id
        JOIN book_issues bi ON bi.issue_id = f.issue_id
        JOIN books b ON b.book_id = bi.book_id";
$params = [];
if ($status_filter !== 'all') {
    $sql .= " WHERE f.status = ?";
    $params[] = $status_filter;
}
$sql .= " ORDER BY f.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$fines = $stmt->fetchAll();

$total_unpaid = $pdo->query("SELECT COALESCE(SUM(amount),0) FROM fines WHERE status='unpaid'")->fetchColumn();
$total_collected = $pdo->query("SELECT COALESCE(SUM(amount),0) FROM fines WHERE status='paid'")->fetchColumn();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="stat-grid mb-4" style="grid-template-columns:repeat(2,1fr);max-width:520px;">
    <div class="stat-card accent-terracotta">
        <div class="stat-label">Outstanding fines</div>
        <div class="stat-value"><?= money($total_unpaid) ?></div>
    </div>
    <div class="stat-card accent-sage">
        <div class="stat-label">Total collected</div>
        <div class="stat-value"><?= money($total_collected) ?></div>
    </div>
</div>

<div class="panel">
    <div class="panel-title">
        <span>Fine records</span>
        <div class="btn-group btn-group-sm">
            <a href="?status=unpaid" class="btn <?= $status_filter==='unpaid' ? 'btn-ink' : 'btn-outline-ink' ?>">Unpaid</a>
            <a href="?status=paid" class="btn <?= $status_filter==='paid' ? 'btn-ink' : 'btn-outline-ink' ?>">Paid</a>
            <a href="?status=waived" class="btn <?= $status_filter==='waived' ? 'btn-ink' : 'btn-outline-ink' ?>">Waived</a>
            <a href="?status=all" class="btn <?= $status_filter==='all' ? 'btn-ink' : 'btn-outline-ink' ?>">All</a>
        </div>
    </div>

    <?php if (!$fines): ?>
        <div class="empty-state"><i class="fa-solid fa-coins"></i>No fines to show for this filter.</div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table table-hover">
            <thead><tr><th>Student</th><th>Book</th><th>Amount</th><th>Reason</th><th>Status</th><th>Raised on</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($fines as $f): ?>
                <tr>
                    <td>
                        <div><?= h($f['full_name']) ?></div>
                        <div class="text-muted-ink" style="font-size:12px;"><?= h($f['email']) ?></div>
                    </td>
                    <td><?= h($f['title']) ?></td>
                    <td style="font-weight:600;"><?= money($f['amount']) ?></td>
                    <td class="text-muted-ink"><?= h($f['reason']) ?></td>
                    <td>
                        <?php
                        $badgeClass = $f['status'] === 'unpaid' ? 'badge-overdue' : ($f['status'] === 'paid' ? 'badge-ok' : 'badge-returned');
                        ?>
                        <span class="badge-soft <?= $badgeClass ?>"><?= ucfirst(h($f['status'])) ?></span>
                    </td>
                    <td class="due-date"><?= date('d M Y', strtotime($f['created_at'])) ?></td>
                    <td class="text-end" style="white-space:nowrap;">
                        <?php if ($f['status'] === 'unpaid'): ?>
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                            <input type="hidden" name="fine_id" value="<?= $f['fine_id'] ?>">
                            <input type="hidden" name="action" value="paid">
                            <button class="btn btn-sm btn-brass"><i class="fa-solid fa-check"></i> Mark Paid</button>
                        </form>
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                            <input type="hidden" name="fine_id" value="<?= $f['fine_id'] ?>">
                            <input type="hidden" name="action" value="waive">
                            <button class="btn btn-sm btn-outline-ink"><i class="fa-solid fa-ban"></i> Waive</button>
                        </form>
                        <?php else: ?>
                            <span class="text-muted-ink" style="font-size:12.5px;">—</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
