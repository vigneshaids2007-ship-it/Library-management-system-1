<?php
/**
 * index.php
 * ---------------------------------------------------------------------
 * Entry point. Sends the visitor to the right place:
 *   - not logged in  -> login page
 *   - admin          -> admin dashboard
 *   - student        -> student dashboard
 * ---------------------------------------------------------------------
 */
require_once __DIR__ . '/config/config.php';

if (!is_logged_in()) {
    header('Location: ' . BASE_URL . '/auth/login.php');
    exit;
}

if ($_SESSION['role'] === 'admin') {
    header('Location: ' . BASE_URL . '/admin/dashboard.php');
} else {
    header('Location: ' . BASE_URL . '/student/dashboard.php');
}
exit;
