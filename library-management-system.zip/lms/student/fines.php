<?php
/**
 * student/fines.php
 * ---------------------------------------------------------------------
 * Read-only view of the logged-in student's fines. Payment is recorded
 * by an admin at the library desk (see admin/fines.php).
 * ---------------------------------------------------------------------
 */
require_once __DIR__ . '/../config/config.php';
require_role('student');
sync_overdue_fines($pdo);

$page_title = 'My Fines';
$active_nav = 'fines';
$uid = $_SESSION['user_id'];

$fines = $pdo->prepare("
    SELECT f.*, b.title
    FROM fines f
    JOIN book_issues bi ON bi.issue_id = f.issue_id
    JOIN books b ON b.book_id = bi.book_id
    WHERE f.user_id = ?
    ORDER BY f.created_at DESC
");
$fines->execute([$uid]);
$fines = $fines->fetchAll();

$unpaid_total = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM fines WHERE user_id=? AND status='unpaid'");
$unpaid_total->execute([$uid]);
$unpaid_total = $unpaid_total->fetchColumn();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="stat-grid mb-4" style="grid-template-columns:1fr; max-width:280px;">
    <div class="stat-card accent-terracotta">
        <div class="stat-label">Total unpaid</div>
        <div class="stat-value"><?= money($unpaid_total) ?></div>
        <div class="stat-sub">Pay at the library desk</div>
    </div>
</div>

<div class="panel mb-0">
    <div class="panel-title"><span>Fine history</span></div>
    <?php if (!$fines): ?>
        <div class="empty-state"><i class="fa-solid fa-face-smile"></i>You have no fines. Keep it up!</div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table table-hover">
            <thead><tr><th>Book</th><th>Amount</th><th>Reason</th><th>Status</th><th>Raised on</th></tr></thead>
            <tbody>
            <?php foreach ($fines as $f): ?>
                <tr>
                    <td><?= h($f['title']) ?></td>
                    <td style="font-weight:600;"><?= money($f['amount']) ?></td>
                    <td class="text-muted-ink"><?= h($f['reason']) ?></td>
                    <td>
                        <?php $badgeClass = $f['status'] === 'unpaid' ? 'badge-overdue' : ($f['status'] === 'paid' ? 'badge-ok' : 'badge-returned'); ?>
                        <span class="badge-soft <?= $badgeClass ?>"><?= ucfirst(h($f['status'])) ?></span>
                    </td>
                    <td class="due-date"><?= date('d M Y', strtotime($f['created_at'])) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
