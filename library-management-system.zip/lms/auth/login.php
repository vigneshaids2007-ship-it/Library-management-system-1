<?php
/**
 * auth/login.php
 * ---------------------------------------------------------------------
 * Handles both displaying the login form and processing the POST.
 * Uses password_verify() against the bcrypt hash stored in `users`.
 * ---------------------------------------------------------------------
 */
require_once __DIR__ . '/../config/config.php';

if (is_logged_in()) {
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

$errors = [];
$old_email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $old_email = $email;

    if ($email === '' || $password === '') {
        $errors[] = 'Please enter both email and password.';
    }

    if (!$errors) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, $user['password'])) {
            $errors[] = 'Invalid email or password.';
        } elseif ($user['status'] === 'blocked') {
            $errors[] = 'This account has been blocked. Please contact the library admin.';
        } else {
            $_SESSION['user_id']   = $user['user_id'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['role']      = $user['role'];
            $_SESSION['email']     = $user['email'];

            set_flash('success', 'Welcome back, ' . $user['full_name'] . '!');
            header('Location: ' . BASE_URL . '/index.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign In · Athenaeum LMS</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="auth-shell">
    <div class="auth-visual">
        <div class="eyebrow">Athenaeum Library</div>
        <h1>Every book, every borrower, one ledger.</h1>
        <p>Track circulation, manage the catalog, and keep overdue fines under control — all from a single, well-organised shelf.</p>
        <div class="shelf-stats">
            <div><strong>8+</strong><span>Titles cataloged</span></div>
            <div><strong>24/7</strong><span>Self-service access</span></div>
            <div><strong>Auto</strong><span>Fine calculation</span></div>
        </div>
    </div>
    <div class="auth-form-side">
        <div class="auth-card">
            <div class="brand-mark">
                <div class="glyph">A</div>
                <span class="font-display fw-semibold fs-4">Athenaeum</span>
            </div>
            <h2>Sign in</h2>
            <p class="sub">Access your library account</p>

            <?php foreach ($errors as $err): ?>
                <div class="alert alert-danger app-alert"><?= h($err) ?></div>
            <?php endforeach; ?>

            <form method="POST" class="needs-validation" novalidate>
                <div class="mb-3">
                    <label class="form-label">Email address</label>
                    <input type="email" name="email" class="form-control" value="<?= h($old_email) ?>" required autofocus>
                    <div class="invalid-feedback">Please enter a valid email.</div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" required>
                    <div class="invalid-feedback">Please enter your password.</div>
                </div>
                <button type="submit" class="btn btn-brass w-100">Sign in</button>
            </form>

            <div class="cred-hint">
                <strong>Demo accounts</strong> (password: <code>Password123</code>)<br>
                Admin — admin@library.com<br>
                Student — aisha@student.com
            </div>

            <p class="text-center mt-4 mb-0" style="font-size:14px;">
                New here? <a href="<?= BASE_URL ?>/auth/register.php">Create a student account</a>
            </p>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>/assets/js/script.js"></script>
</body>
</html>
