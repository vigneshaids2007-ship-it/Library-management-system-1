<?php
/**
 * auth/logout.php
 * ---------------------------------------------------------------------
 * Destroys the session and returns the visitor to the login page.
 * ---------------------------------------------------------------------
 */
require_once __DIR__ . '/../config/config.php';

$_SESSION = [];
session_destroy();

session_start();
set_flash('success', 'You have been signed out.');
header('Location: ' . BASE_URL . '/auth/login.php');
exit;
